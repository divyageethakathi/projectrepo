import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup,FormArray, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService, AuthenticationService ,UserService} from '../../app/_services';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { User } from '../../app/_models';


@Component({templateUrl: '../feed-list/feed-list.component.html'})
export class FeedListComponent implements OnInit {
  loading = false;
  submitted = false;
  returnUrl: string;
  dynamicForm: FormGroup;
  arrFeeds: any [];
  users: User[] = [];
  config: any;
  collection = { count: 60, data: [] };
  
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private httpService: HttpClient
) { 
  // redirect to home if already logged in
  if (this.authenticationService.currentUserValue) { 
    this.router.navigate(['/feed-list']);
  } 
 }
    
    ngOnInit() {
        this.dynamicForm = this.formBuilder.group({
            count: ['', Validators.required],
            name: ['', Validators.required],
            email: ['', Validators.required],
            feed: ['', Validators.required],
            createdOn: ['', Validators.required],
            tickets: new FormArray([])
        });
        
        this.httpService.get('./assets/feeds.json').subscribe(
            data => {
              this.arrFeeds = data as string [];
              this.arrFeeds.push({name:this.authenticationService.currentUserValue.name,
                                   email:this.authenticationService.currentUserValue.email,
                                  feed:this.authenticationService.currentUserValue.feed});
              this.collection.data=this.arrFeeds;

              	 // FILL THE ARRAY WITH DATA.
            },
            (err: HttpErrorResponse) => {
              console.log (err.message);
            }
          );
          

          for (var i = 0; i < this.collection.count; i++) {
            this.collection.data.push(
              {
                id: i + 1,
                value: "items number " + (i + 1)
              }
            );
            }
        
            this.config = {
              itemsPerPage: 4,
              currentPage: 1,
              totalItems: this.collection.count
            };
    }
    pageChanged(event){
      this.config.currentPage = event;
      } 
    // convenience getters for easy access to form fields
    get f() { return this.dynamicForm.controls; }
    get t() { return this.f.tickets as FormArray; }
    
    getFeedList() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.dynamicForm.invalid) {
          return;
      }
      
      this.loading = true;
      this.authenticationService.getFeedList(this.f.title.value, this.f.feed.value,this.authenticationService.currentUserValue.email,this.authenticationService.currentUserValue.password)
          .pipe(first())
          .subscribe(
              data => {
                
              },
              error => {
                  this.alertService.error(error);
                  this.loading = false;
              });
    }
  }

