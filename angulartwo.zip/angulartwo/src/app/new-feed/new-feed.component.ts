import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService, AuthenticationService } from '../../app/_services';

@Component({templateUrl: '../new-feed/new-feed.component.html'})
export class NewFeedComponent implements OnInit {
  newFeedForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  @Input() email:string;
  @Input() password:string;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private authenticationService: AuthenticationService,
) { 
  // redirect to home if already logged in
  if (this.authenticationService.currentUserValue) { 
    this.router.navigate(['/new-feed']);
}
}

ngOnInit() {
  this.newFeedForm = this.formBuilder.group({
      title: ['', Validators.required],
      feed: ['', Validators.required],
      email: [''],
      password: ['']
  });

  // get return url from route parameters or default to '/'
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
}

// convenience getter for easy access to form fields
get f() { return this.newFeedForm.controls; }

saveFeed() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.newFeedForm.invalid) {
      return;
  }
  
  this.loading = true;
  this.authenticationService.saveFeed(this.f.title.value, this.f.feed.value,this.authenticationService.currentUserValue.email,this.authenticationService.currentUserValue.password)
      .pipe(first())
      .subscribe(
          data => {
            this.alertService.success('New Feed is added successful', true);
            this.router.navigate(['/home']);
          },
          error => {
              this.alertService.error(error);
              this.loading = false;
          });
}
}
