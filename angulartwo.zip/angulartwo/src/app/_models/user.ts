﻿export class User {
    id: number;
    name:string;
    email:string;
    password: string;
    confirmpassword: string;
    city: string;
    country: string;
    title:string;
    feed:string;
    count:number;
    token: string;
    ticket:string;
    createdOn:Date;
}