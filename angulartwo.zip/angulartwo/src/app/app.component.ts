import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { AuthenticationService } from './_services';
import { User } from './_models';

@Component({ selector: 'app', templateUrl: 'app.component.html' })
export class AppComponent {
    title(title: any) {
      throw new Error("Method not implemented.");
    }
    currentUser: User;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) {
        this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    }

    newfeed() {
        this.router.navigate(['/new-feed']);
    }
    feedlist() {
        this.router.navigate(['/feed-list']);
    }
    logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }
}